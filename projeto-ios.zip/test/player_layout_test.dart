import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:video_player_platform_interface/video_player_platform_interface.dart';
import 'package:rauny_iptv_player/main.dart';

class LayoutVideoPlatform extends VideoPlayerPlatform {
  @override Future<void> init() async {}
  @override Future<void> setPreventsDisplaySleepDuringVideoPlayback(int id, bool value) async {}
  @override Future<int> createWithOptions(VideoCreationOptions options) async => 1;
  @override Stream<VideoEvent> videoEventsFor(int id) => Stream.value(VideoEvent(
    eventType: VideoEventType.initialized, duration: const Duration(minutes: 10),
    size: const Size(1280, 720)));
  @override Widget buildView(int id) => const ColoredBox(color: Colors.black);
  @override Future<void> play(int id) async {}
  @override Future<void> pause(int id) async {}
  @override Future<void> setVolume(int id, double value) async {}
  @override Future<void> setLooping(int id, bool value) async {}
  @override Future<void> setPlaybackSpeed(int id, double value) async {}
  @override Future<void> seekTo(int id, Duration position) async {}
  @override Future<Duration> getPosition(int id) async => const Duration(seconds: 12);
  @override Future<void> dispose(int id) async {}
}

void main() {
  for (final type in ['live', 'movie', 'series']) {
    testWidgets('Controles de $type cabem em celular estreito', (tester) async {
      SharedPreferences.setMockInitialValues({});
      final old = VideoPlayerPlatform.instance;
      VideoPlayerPlatform.instance = LayoutVideoPlatform();
      addTearDown(() => VideoPlayerPlatform.instance = old);
      tester.view.physicalSize = const Size(320, 760);
      tester.view.devicePixelRatio = 1;
      addTearDown(tester.view.resetPhysicalSize);
      addTearDown(tester.view.resetDevicePixelRatio);
      final api = XtreamApi(Uri.parse('https://fixture.invalid/'), 'fixture', 'fixture');
      await tester.pumpWidget(MaterialApp(home: PlayerPage(
        title: 'Vídeo de teste', url: Uri.parse('https://fixture.invalid/video'),
        mediaType: type, api: api, remainingEpisodes: type == 'series'
            ? const [{'id': '2', 'title': 'Próximo'}] : const [])));
      await tester.pumpAndSettle();
      expect(tester.takeException(), isNull);
      await tester.pumpWidget(const SizedBox());
      await tester.pump();
    });
  }
}
