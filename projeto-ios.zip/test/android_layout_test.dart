import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:rauny_iptv_player/main.dart';

void main() {
  setUp(() => SharedPreferences.setMockInitialValues({}));

  testWidgets('Primeira abertura apresenta o login no celular', (tester) async {
    tester.view.physicalSize = const Size(360, 800);
    tester.view.devicePixelRatio = 1;
    addTearDown(tester.view.resetPhysicalSize);
    addTearDown(tester.view.resetDevicePixelRatio);
    await tester.pumpWidget(const RaunyIptvPlayer());
    await tester.pumpAndSettle();
    expect(find.text('Conectar à minha lista'), findsOneWidget);
    expect(find.text('Manter conectado'), findsOneWidget);
    expect(tester.takeException(), isNull);
  });

  for (final width in [320.0, 360.0, 412.0]) {
    testWidgets('Início cabe na largura de $width pontos', (tester) async {
      tester.view.physicalSize = Size(width, 850);
      tester.view.devicePixelRatio = 1;
      addTearDown(tester.view.resetPhysicalSize);
      addTearDown(tester.view.resetDevicePixelRatio);
      final api = XtreamApi(Uri.parse('https://fixture.invalid/'), 'fixture', 'fixture');
      final store = await VisibilityStore.load(api);
      await store.loadParental();
      await tester.pumpWidget(MaterialApp(home: HomePage(api: api, visibility: store)));
      await tester.pumpAndSettle();
      expect(find.text('Seu entretenimento, do seu jeito.'), findsOneWidget);
      expect(tester.takeException(), isNull);
    });
  }
}
