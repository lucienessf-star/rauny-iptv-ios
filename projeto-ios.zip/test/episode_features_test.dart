import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:video_player_platform_interface/video_player_platform_interface.dart';
import 'package:rauny_iptv_player/main.dart';
import 'package:rauny_iptv_player/episode_history.dart';
import 'player_layout_test.dart' show LayoutVideoPlatform;

class EpisodeApi extends XtreamApi {
  EpisodeApi() : super(Uri.parse('https://fixture.invalid/'), 'fixture', 'fixture');
  @override Future<dynamic> get(String action, [Map<String, String> extra = const {}]) async => {
    'episodes': {
      '1': [{'id': '100', 'title': 'Primeiro episódio', 'container_extension': 'mp4'}],
      '2': [{'id': '200', 'title': 'Outro episódio', 'container_extension': 'mp4'}],
    },
  };
}

class EpisodePlatform extends LayoutVideoPlatform {
  Duration position = const Duration(seconds: 10);
  final seeks = <Duration>[];
  int openings = 0, disposals = 0;
  @override Future<int> createWithOptions(VideoCreationOptions options) async => ++openings;
  @override Stream<VideoEvent> videoEventsFor(int id) => Stream.value(VideoEvent(
    eventType: VideoEventType.initialized, duration: const Duration(seconds: 100), size: const Size(1280, 720)));
  @override Future<Duration> getPosition(int id) async => position;
  @override Future<void> seekTo(int id, Duration value) async { position = value; seeks.add(value); }
  @override Future<void> dispose(int id) async { disposals++; }
}

void main() {
  setUp(() => SharedPreferences.setMockInitialValues({}));

  test('Marcações persistem por episódio/conta e permitem desfazer', () async {
    await Future.wait([
      EpisodeHistory.setWatched('a', '100', true), EpisodeHistory.setWatched('a', '200', true)]);
    expect(await EpisodeHistory.load('a'), {'100', '200'});
    expect(await EpisodeHistory.load('b'), isEmpty);
    await EpisodeHistory.setWatched('a', '100', false);
    expect(await EpisodeHistory.load('a'), {'200'});
    final prefs = await SharedPreferences.getInstance();
    expect(prefs.getBool(EpisodeHistory.key('a', '100')), false);
  });

  test('Limiar de assistido exige 90% ou conclusão e duração válida', () {
    expect(EpisodeHistory.reachedEnd(const Duration(seconds: 89), const Duration(seconds: 100)), false);
    expect(EpisodeHistory.reachedEnd(const Duration(seconds: 90), const Duration(seconds: 100)), true);
    expect(EpisodeHistory.reachedEnd(Duration.zero, const Duration(seconds: 100), completed: true), true);
    expect(EpisodeHistory.reachedEnd(const Duration(days: 1), Duration.zero), false);
  });

  test('Progresso antigo compatível é aproveitado sem sobrescrever escolha manual', () async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('watch_v11_a_series_100', jsonEncode({'position': 95, 'duration': 100}));
    expect(await EpisodeHistory.load('a'), {'100'});
    await EpisodeHistory.setWatched('a', '100', false);
    expect(await EpisodeHistory.load('a'), isEmpty);
  });

  testWidgets('Lista destaca assistido e permite desfazer sem alterar outra temporada', (tester) async {
    final api = EpisodeApi();
    final scope = WatchProgress.scope(api);
    await EpisodeHistory.setWatched(scope, '100', true);
    await tester.pumpWidget(MaterialApp(home: SeriesPage(api: api, seriesId: '1', title: 'Minha série')));
    await tester.pumpAndSettle();
    expect(find.text('Assistido'), findsOneWidget);
    final title = tester.widget<Text>(find.text('Primeiro episódio'));
    expect(title.style?.color, const Color(0xFFFFCE66));
    await tester.tap(find.byTooltip('Marcar episódio').first);
    await tester.pumpAndSettle();
    await tester.tap(find.text('Marcar como não assistido'));
    await tester.pumpAndSettle();
    expect(find.text('Assistido'), findsNothing);
    await tester.tap(find.byTooltip('Marcar episódio').last);
    await tester.pumpAndSettle();
    await tester.tap(find.text('Marcar como assistido'));
    await tester.pumpAndSettle();
    expect(await EpisodeHistory.load(scope), {'200'});
    await tester.pumpWidget(const SizedBox());
    await tester.pumpWidget(MaterialApp(home: SeriesPage(api: api, seriesId: '1', title: 'Minha série')));
    await tester.pumpAndSettle();
    expect(find.text('Assistido'), findsOneWidget);
    expect(tester.widget<Text>(find.text('Outro episódio')).style?.color, const Color(0xFFFFCE66));
    await tester.pumpWidget(const SizedBox());
  });

  testWidgets('Pular introdução é opcional e desaparece após usar', (tester) async {
    final old = VideoPlayerPlatform.instance, platform = EpisodePlatform()..position = Duration.zero;
    VideoPlayerPlatform.instance = platform;
    addTearDown(() => VideoPlayerPlatform.instance = old);
    tester.view.devicePixelRatio = 1;
    tester.view.physicalSize = const Size(844, 390);
    addTearDown(tester.view.resetPhysicalSize);
    addTearDown(tester.view.resetDevicePixelRatio);
    await tester.pumpWidget(MaterialApp(home: PlayerPage(title: 'Episódio',
      url: Uri.parse('https://fixture.invalid/ep.mp4'), mediaType: 'series')));
    await tester.pumpAndSettle();
    await tester.pump(const Duration(seconds: 1));
    expect(platform.seeks, isEmpty);
    expect(find.text('Pular introdução (+60s)'), findsOneWidget);
    await tester.tap(find.text('Pular introdução (+60s)'));
    await tester.pump();
    expect(platform.seeks.last, const Duration(seconds: 60));
    expect(find.text('Pular introdução (+60s)'), findsNothing);
    await tester.pump(const Duration(seconds: 4));
    await tester.pump();
    expect(find.text('Pular introdução (+60s)'), findsNothing);
    await tester.tapAt(const Offset(420, 80));
    await tester.pump();
    expect(find.text('Pular introdução (+60s)'), findsNothing);
    expect(platform.openings, 1);
    expect(tester.takeException(), isNull);
    await tester.pumpWidget(const SizedBox());
    await tester.pump();
  });

  testWidgets('Introdução expira em 10 segundos e não reaparece ao tocar', (tester) async {
    final old = VideoPlayerPlatform.instance;
    final platform = EpisodePlatform()..position = Duration.zero;
    VideoPlayerPlatform.instance = platform;
    addTearDown(() => VideoPlayerPlatform.instance = old);
    await tester.pumpWidget(MaterialApp(home: PlayerPage(title: 'Episódio',
      url: Uri.parse('https://fixture.invalid/intro.mp4'), mediaType: 'series')));
    await tester.pumpAndSettle();
    expect(find.text('Pular introdução (+60s)'), findsOneWidget);
    await tester.pump(const Duration(seconds: 9));
    await tester.tapAt(const Offset(300, 200));
    await tester.pump();
    expect(find.text('Pular introdução (+60s)'), findsOneWidget);
    await tester.pump(const Duration(seconds: 1));
    await tester.pump();
    expect(find.text('Pular introdução (+60s)'), findsNothing);
    await tester.tapAt(const Offset(300, 200));
    await tester.pump();
    expect(find.text('Pular introdução (+60s)'), findsNothing);
    expect(platform.seeks, isEmpty);
    await tester.pumpWidget(const SizedBox());
    await tester.pump();
  });

  testWidgets('Home volta direto à raiz e salva episódio assistido separado do progresso', (tester) async {
    final old = VideoPlayerPlatform.instance, platform = EpisodePlatform();
    VideoPlayerPlatform.instance = platform;
    addTearDown(() => VideoPlayerPlatform.instance = old);
    final nav = GlobalKey<NavigatorState>();
    await tester.pumpWidget(MaterialApp(navigatorKey: nav,
      home: const Scaffold(body: Text('Menu principal'))));
    nav.currentState!.push(MaterialPageRoute<void>(builder: (_) => const Scaffold(body: Text('Categorias'))));
    await tester.pumpAndSettle();
    nav.currentState!.push(MaterialPageRoute<void>(builder: (_) => PlayerPage(title: 'Episódio',
      url: Uri.parse('https://fixture.invalid/ep2.mp4'), mediaType: 'series', mediaId: '100', progressScope: 'a')));
    await tester.pumpAndSettle();
    platform.position = const Duration(seconds: 95);
    await tester.pump(const Duration(seconds: 1));
    await tester.pump();
    expect(await EpisodeHistory.load('a'), {'100'});
    await tester.tap(find.byTooltip('Início (Home)'));
    await tester.pumpAndSettle();
    expect(find.text('Menu principal'), findsOneWidget);
    expect(find.text('Categorias'), findsNothing);
    expect(await EpisodeHistory.load('a'), {'100'});
    expect(await WatchProgress.get('a', 'series', '100'), isNull);
    await tester.pump(const Duration(seconds: 1));
    await tester.pump();
    await tester.runAsync(() => Future<void>.delayed(const Duration(milliseconds: 10)));
    expect(platform.disposals, 1);
  });
}
