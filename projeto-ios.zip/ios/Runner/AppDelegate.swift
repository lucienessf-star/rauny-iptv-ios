import Flutter
import UIKit

@main
@objc class AppDelegate: FlutterAppDelegate, FlutterImplicitEngineDelegate {
  private var downloadsChannel: FlutterMethodChannel?
  private var downloadedFiles: [String: URL] = [:]
  override func application(
    _ application: UIApplication,
    didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?
  ) -> Bool {
    return super.application(application, didFinishLaunchingWithOptions: launchOptions)
  }

  func didInitializeImplicitFlutterEngine(_ engineBridge: FlutterImplicitEngineBridge) {
    GeneratedPluginRegistrant.register(with: engineBridge.pluginRegistry)
    let channel = FlutterMethodChannel(name: "rauny/downloads",
      binaryMessenger: engineBridge.applicationRegistrar.messenger())
    downloadsChannel = channel
    channel.setMethodCallHandler { [weak self] call, result in
      guard let self = self else { return }
      switch call.method {
      case "download": self.download(call, result: result)
      case "openDownloads": self.shareDownload(call, result: result)
      default: result(FlutterMethodNotImplemented)
      }
    }
  }

  private func download(_ call: FlutterMethodCall, result: @escaping FlutterResult) {
    guard let args = call.arguments as? [String: Any],
      let rawURL = args["url"] as? String, let url = URL(string: rawURL),
      let scheme = url.scheme, ["http", "https"].contains(scheme),
      url.host != nil, let kind = args["mediaType"] as? String,
      ["movie", "series"].contains(kind),
      let rawExtension = args["extension"] as? String else {
      result(FlutterError(code: "UNSUPPORTED_FORMAT", message: "Formato indisponível.", details: nil))
      return
    }
    let ext = rawExtension.lowercased().trimmingCharacters(in: CharacterSet(charactersIn: "."))
    let allowed = ["mp4", "mkv", "avi", "mov", "m4v", "webm", "mpg", "mpeg", "ts", "m2ts", "wmv", "3gp"]
    guard allowed.contains(ext), !["m3u8", "m3u", "mpd"].contains(url.pathExtension.lowercased()) else {
      result(FlutterError(code: "UNSUPPORTED_FORMAT", message: "Playlist não suportada.", details: nil))
      return
    }
    let rawTitle = args["title"] as? String ?? "Vídeo"
    let title = String(rawTitle.prefix(100)).replacingOccurrences(of: "[^\\p{L}\\p{N} ._()-]",
      with: "_", options: .regularExpression)
    URLSession.shared.downloadTask(with: url) { [weak self] temporaryURL, response, error in
      let finish: (FlutterError) -> Void = { failure in DispatchQueue.main.async { result(failure) } }
      guard error == nil, let temporaryURL = temporaryURL,
        let http = response as? HTTPURLResponse, (200...299).contains(http.statusCode) else {
        finish(FlutterError(code: "DOWNLOAD_FAILED", message: "Falha ao baixar o vídeo.", details: nil))
        return
      }
      // Não salva playlists ou páginas de erro com extensão de vídeo.
      let mime = http.mimeType?.lowercased() ?? ""
      guard !mime.contains("mpegurl"), !mime.contains("dash+xml"), !mime.contains("text/html") else {
        finish(FlutterError(code: "UNSUPPORTED_FORMAT", message: "Resposta não é arquivo de vídeo.", details: nil))
        return
      }
      do {
        let folder = try FileManager.default.url(for: .documentDirectory, in: .userDomainMask,
          appropriateFor: nil, create: true).appendingPathComponent("Downloads", isDirectory: true)
        try FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true)
        let destination = folder.appendingPathComponent("Rauny_\(title)_\(UUID().uuidString).\(ext)")
        try FileManager.default.moveItem(at: temporaryURL, to: destination)
        DispatchQueue.main.async {
          self?.downloadedFiles[rawURL] = destination
          result(0)
        }
      } catch {
        finish(FlutterError(code: "DOWNLOAD_FAILED", message: "Não foi possível salvar o arquivo.", details: nil))
      }
    }.resume()
  }

  private func shareDownload(_ call: FlutterMethodCall, result: @escaping FlutterResult) {
    let args = call.arguments as? [String: Any]
    guard let rawURL = args?["url"] as? String, let file = downloadedFiles[rawURL],
      FileManager.default.fileExists(atPath: file.path),
      let scene = UIApplication.shared.connectedScenes.first(where: { $0.activationState == .foregroundActive }) as? UIWindowScene,
      let root = scene.windows.first(where: { $0.isKeyWindow })?.rootViewController else {
      result(FlutterError(code: "UNAVAILABLE", message: "Abra o app Arquivos para localizar Downloads.", details: nil))
      return
    }
    var presenter = root
    while let presented = presenter.presentedViewController { presenter = presented }
    let share = UIActivityViewController(activityItems: [file], applicationActivities: nil)
    share.popoverPresentationController?.sourceView = presenter.view
    share.popoverPresentationController?.sourceRect = CGRect(x: presenter.view.bounds.midX,
      y: presenter.view.bounds.midY, width: 1, height: 1)
    presenter.present(share, animated: true)
    result(nil)
  }
}
