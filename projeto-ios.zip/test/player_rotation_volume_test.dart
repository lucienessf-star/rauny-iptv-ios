import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:video_player_platform_interface/video_player_platform_interface.dart';
import 'package:rauny_iptv_player/main.dart';
import 'player_layout_test.dart' show LayoutVideoPlatform;

class TrackedPlatform extends LayoutVideoPlatform {
  int openings = 0;
  final volumes = <double>[];
  @override Future<int> createWithOptions(VideoCreationOptions options) async => ++openings;
  @override Future<void> setVolume(int id, double value) async { volumes.add(value); }
}

void main() {
  for (final size in [const Size(390, 844), const Size(800, 1280)]) {
    testWidgets('Rotação expande e retorna sem reabrir vídeo em $size', (tester) async {
      SharedPreferences.setMockInitialValues({});
      final old = VideoPlayerPlatform.instance;
      final platform = TrackedPlatform();
      VideoPlayerPlatform.instance = platform;
      addTearDown(() => VideoPlayerPlatform.instance = old);
      tester.view.devicePixelRatio = 1;
      tester.view.physicalSize = size;
      addTearDown(tester.view.resetPhysicalSize);
      addTearDown(tester.view.resetDevicePixelRatio);
      await tester.pumpWidget(MaterialApp(home: PlayerPage(title: 'Canal',
        url: Uri.parse('https://fixture.invalid/live'), mediaType: 'live')));
      await tester.pumpAndSettle();
      expect(find.byType(AppBar), findsOneWidget);
      tester.view.physicalSize = Size(size.height, size.width);
      await tester.pumpAndSettle();
      expect(find.byType(AppBar), findsNothing);
      expect(find.byTooltip('Sair da tela ampliada'), findsOneWidget);
      tester.view.physicalSize = size;
      await tester.pumpAndSettle();
      expect(find.byType(AppBar), findsOneWidget);
      expect(platform.openings, 1);
      expect(tester.takeException(), isNull);
      await tester.pumpWidget(const SizedBox());
      await tester.pump();
    });
  }

  testWidgets('Ícone silencia e recupera volume ajustado no slider', (tester) async {
    SharedPreferences.setMockInitialValues({});
    final old = VideoPlayerPlatform.instance;
    final platform = TrackedPlatform();
    VideoPlayerPlatform.instance = platform;
    addTearDown(() => VideoPlayerPlatform.instance = old);
    await tester.pumpWidget(MaterialApp(home: PlayerPage(title: 'Filme',
      url: Uri.parse('https://fixture.invalid/movie'), mediaType: 'movie')));
    await tester.pumpAndSettle();
    tester.widget<Slider>(find.byType(Slider)).onChanged!(0.35);
    await tester.pumpAndSettle();
    await tester.tap(find.byTooltip('Silenciar áudio'));
    await tester.pumpAndSettle();
    expect(platform.volumes.last, 0);
    expect(tester.widget<Slider>(find.byType(Slider)).value, 0);
    await tester.tap(find.byTooltip('Ativar áudio'));
    await tester.pumpAndSettle();
    expect(platform.volumes.last, 0.35);
    expect(tester.widget<Slider>(find.byType(Slider)).value, 0.35);
    expect(platform.openings, 1);
    await tester.pumpWidget(const SizedBox());
    await tester.pump();
  });
}
