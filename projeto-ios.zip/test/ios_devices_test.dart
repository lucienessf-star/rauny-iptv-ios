import 'dart:async';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:video_player_platform_interface/video_player_platform_interface.dart';
import 'package:rauny_iptv_player/main.dart';
import 'player_layout_test.dart' show LayoutVideoPlatform;

void main() {
  setUp(() {
    SharedPreferences.setMockInitialValues({});
  });

  for (final size in [const Size(390, 844), const Size(810, 1080), const Size(1024, 1366)]) {
    testWidgets('Início iOS cabe em $size', (tester) async {
      tester.view.devicePixelRatio = 1;
      tester.view.physicalSize = size;
      addTearDown(tester.view.resetPhysicalSize);
      addTearDown(tester.view.resetDevicePixelRatio);
      final api = XtreamApi(Uri.parse('https://fixture.invalid/'), 'fixture', 'fixture');
      final store = await VisibilityStore.load(api);
      await store.loadParental();
      await tester.pumpWidget(MaterialApp(home: HomePage(api: api, visibility: store)));
      await tester.pumpAndSettle();
      expect(tester.takeException(), isNull);
    }, variant: TargetPlatformVariant.only(TargetPlatform.iOS));

    testWidgets('Player iOS gira sem reiniciar e mantém download/mute em $size', (tester) async {
      final systemCalls = <MethodCall>[];
      tester.binding.defaultBinaryMessenger.setMockMethodCallHandler(SystemChannels.platform, (call) async {
        systemCalls.add(call);
        return null;
      });
      addTearDown(() => tester.binding.defaultBinaryMessenger.setMockMethodCallHandler(SystemChannels.platform, null));
      final old = VideoPlayerPlatform.instance;
      VideoPlayerPlatform.instance = LayoutVideoPlatform();
      addTearDown(() => VideoPlayerPlatform.instance = old);
      tester.view.devicePixelRatio = 1;
      tester.view.physicalSize = size;
      addTearDown(tester.view.resetPhysicalSize);
      addTearDown(tester.view.resetDevicePixelRatio);
      await tester.pumpWidget(MaterialApp(home: PlayerPage(title: 'Série iOS',
        url: Uri.parse('https://fixture.invalid/ios-episode.mp4'), mediaType: 'series')));
      await tester.pumpAndSettle();
      expect(find.text('Baixar episódio'), findsOneWidget);
      expect(find.byType(AppBar), findsOneWidget);
      tester.view.physicalSize = Size(size.height, size.width);
      await tester.pumpAndSettle();
      expect(find.byType(AppBar), findsNothing);
      expect(systemCalls.any((call) => call.method == 'SystemChrome.setEnabledSystemUIMode' &&
        call.arguments == 'SystemUiMode.immersiveSticky'), isTrue);
      await tester.pump(const Duration(seconds: 4));
      await tester.pump();
      expect(find.text('Baixar episódio'), findsNothing);
      await tester.tapAt(const Offset(300, 100));
      await tester.pump();
      expect(find.text('Baixar episódio'), findsOneWidget);
      await tester.tap(find.byTooltip('Silenciar áudio'));
      await tester.pump();
      expect(find.byTooltip('Ativar áudio'), findsOneWidget);
      tester.view.physicalSize = size;
      await tester.pumpAndSettle();
      expect(find.byType(AppBar), findsOneWidget);
      expect(systemCalls.any((call) => call.method == 'SystemChrome.setEnabledSystemUIMode' &&
        call.arguments == 'SystemUiMode.edgeToEdge'), isTrue);
      expect(tester.takeException(), isNull);
      await tester.pumpWidget(const SizedBox());
      await tester.pump();
    }, variant: TargetPlatformVariant.only(TargetPlatform.iOS));
  }

  testWidgets('iOS só informa vídeo salvo após o download terminar', (tester) async {
    tester.view.devicePixelRatio = 1;
    tester.view.physicalSize = const Size(390, 844);
    addTearDown(tester.view.resetPhysicalSize);
    addTearDown(tester.view.resetDevicePixelRatio);
    final old = VideoPlayerPlatform.instance;
    VideoPlayerPlatform.instance = LayoutVideoPlatform();
    addTearDown(() => VideoPlayerPlatform.instance = old);
    final completed = Completer<int>();
    final calls = <MethodCall>[];
    const channel = MethodChannel('rauny/downloads');
    tester.binding.defaultBinaryMessenger.setMockMethodCallHandler(channel, (call) async {
      calls.add(call);
      if (call.method == 'download') return completed.future;
      return null;
    });
    addTearDown(() => tester.binding.defaultBinaryMessenger.setMockMethodCallHandler(channel, null));
    await tester.pumpWidget(MaterialApp(home: PlayerPage(title: 'Filme iOS',
      url: Uri.parse('https://fixture.invalid/ios-download.mp4'), mediaType: 'movie')));
    await tester.pumpAndSettle();
    await tester.tap(find.text('Baixar filme'));
    await tester.pump();
    expect(find.text('Baixando...'), findsOneWidget);
    expect(find.text('Vídeo salvo'), findsNothing);
    tester.view.physicalSize = const Size(844, 390);
    await tester.pumpAndSettle();
    await tester.pump(const Duration(seconds: 4));
    await tester.pump();
    expect(find.text('Baixando...'), findsNothing);
    await tester.tapAt(const Offset(400, 100));
    await tester.pump();
    expect(find.text('Baixando...'), findsOneWidget);
    expect(calls.where((call) => call.method == 'download').length, 1);
    completed.complete(0);
    await tester.pumpAndSettle();
    expect(find.text('Vídeo salvo'), findsOneWidget);
    await tester.tap(find.text('Vídeo salvo'));
    await tester.pump();
    expect(calls.last.method, 'openDownloads');
    expect((calls.last.arguments as Map)['url'], 'https://fixture.invalid/ios-download.mp4');
    expect(tester.takeException(), isNull);
    await tester.pumpWidget(const SizedBox());
    await tester.pump();
  }, variant: TargetPlatformVariant.only(TargetPlatform.iOS));
}
