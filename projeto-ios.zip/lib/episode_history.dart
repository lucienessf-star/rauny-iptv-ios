import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class EpisodeHistory {
  static final changes = ValueNotifier<int>(0);
  static String prefix(String scope) => 'watched_v150_${scope}_episode_';
  static String key(String scope, String id) => '${prefix(scope)}$id';

  static bool reachedEnd(Duration position, Duration duration, {bool completed = false}) =>
      duration > Duration.zero && (completed || position.inMilliseconds >= duration.inMilliseconds * .9);

  static Future<void> setWatched(String scope, String id, bool watched) async {
    if (scope.isEmpty || id.isEmpty) return;
    final prefs = await SharedPreferences.getInstance();
    // Um registro por episódio evita perda de marcações em gravações simultâneas.
    await prefs.setBool(key(scope, id), watched);
    changes.value++;
  }

  static Future<Set<String>> load(String scope) async {
    if (scope.isEmpty) return {};
    final prefs = await SharedPreferences.getInstance();
    final watched = <String>{};
    final legacyPrefix = 'watch_v11_${scope}_series_';
    // Recupera progressos antigos ainda presentes. Conclusões removidas na
    // versão anterior não podem ser deduzidas; a marcação manual cobre esse caso.
    for (final oldKey in prefs.getKeys()) {
      if (!oldKey.startsWith(legacyPrefix)) continue;
      final id = oldKey.substring(legacyPrefix.length);
      if (prefs.containsKey(key(scope, id))) continue;
      try {
        final data = jsonDecode(prefs.getString(oldKey) ?? '');
        if (data is Map && data['position'] is num && data['duration'] is num &&
            reachedEnd(Duration(seconds: (data['position'] as num).toInt()),
                Duration(seconds: (data['duration'] as num).toInt()))) {
          await prefs.setBool(key(scope, id), true);
        }
      } catch (_) {}
    }
    for (final k in prefs.getKeys()) {
      if (k.startsWith(prefix(scope)) && prefs.getBool(k) == true) {
        watched.add(k.substring(prefix(scope).length));
      }
    }
    return watched;
  }
}

class EpisodeTile extends StatelessWidget {
  final String title;
  final bool watched;
  final VoidCallback onPlay;
  final ValueChanged<bool> onMark;
  const EpisodeTile({super.key, required this.title, required this.watched,
      required this.onPlay, required this.onMark});
  @override Widget build(BuildContext context) => ListTile(
    leading: Icon(watched ? Icons.check_circle : Icons.play_circle_outline,
      color: watched ? const Color(0xFFFFCE66) : null),
    title: Text(title, style: TextStyle(color: watched ? const Color(0xFFFFCE66) : null)),
    subtitle: watched ? const Text('Assistido', style: TextStyle(color: Color(0xFFFFCE66))) : null,
    onTap: onPlay,
    trailing: PopupMenuButton<bool>(tooltip: 'Marcar episódio',
      onSelected: onMark,
      itemBuilder: (_) => [PopupMenuItem(value: !watched,
        child: Text(watched ? 'Marcar como não assistido' : 'Marcar como assistido'))]),
  );
}

class HomeButton extends StatelessWidget {
  final VoidCallback? onPressed;
  const HomeButton({super.key, this.onPressed});
  @override Widget build(BuildContext context) => IconButton(
    tooltip: 'Início (Home)', icon: const Icon(Icons.home_rounded),
    onPressed: onPressed ?? () => Navigator.of(context).popUntil((route) => route.isFirst));
}
