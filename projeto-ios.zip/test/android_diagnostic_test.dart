import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:video_player_platform_interface/video_player_platform_interface.dart';
import 'package:rauny_iptv_player/main.dart';
import 'player_layout_test.dart' show LayoutVideoPlatform;

class FailureThenSuccessPlatform extends LayoutVideoPlatform {
  int openings = 0;
  @override
  Future<int> createWithOptions(VideoCreationOptions options) async => ++openings;
  @override
  Stream<VideoEvent> videoEventsFor(int id) => id == 1
      ? Stream.error(PlatformException(code: 'VideoError', message:
          'ANDROID_MEDIA3 code=2004; ERROR_CODE_IO_BAD_HTTP_STATUS; cause=InvalidResponseCodeException; HTTP=403'))
      : super.videoEventsFor(id);
}

void main() {
  test('Diagnóstico omite URLs e mensagens com credenciais', () {
    expect(nativeVideoDiagnostic(PlatformException(code: 'VideoError', message:
        'Falha https://servidor/usuario/senha')), isNot(contains('servidor')));
    expect(nativeVideoDiagnostic(PlatformException(code: 'VideoError', message:
        'ANDROID_MEDIA3 code=2004; ERROR_CODE_IO_BAD_HTTP_STATUS; cause=InvalidResponseCodeException; HTTP=403 https://segredo')),
        'ANDROID_MEDIA3 code=2004; ERROR_CODE_IO_BAD_HTTP_STATUS; cause=InvalidResponseCodeException; HTTP=403');
    expect(nativeVideoDiagnostic(TimeoutException('segredo')), contains('25 segundos'));
  });

  test('Capas usam campos consistentes e ignoram valores vazios', () {
    final item = <String, dynamic>{'cover': 'https://fixture.invalid/serie.jpg',
      'stream_icon': 'https://fixture.invalid/filme.jpg'};
    expect(mediaPoster(item), item['stream_icon']);
    expect(mediaPoster(item, series: true), item['cover']);
    expect(mediaPoster({'stream_icon': 'null', 'cover': item['cover']}), item['cover']);
  });

  testWidgets('Falha mostra diagnóstico e botão abre outro controlador', (tester) async {
    SharedPreferences.setMockInitialValues({});
    final old = VideoPlayerPlatform.instance;
    final platform = FailureThenSuccessPlatform();
    VideoPlayerPlatform.instance = platform;
    addTearDown(() => VideoPlayerPlatform.instance = old);
    final api = XtreamApi(Uri.parse('https://fixture.invalid/'), 'fixture', 'fixture');
    await tester.pumpWidget(MaterialApp(home: PlayerPage(title: 'Canal',
      url: Uri.parse('https://fixture.invalid/live'), mediaType: 'live', api: api)));
    await tester.pumpAndSettle();
    expect(find.textContaining('HTTP=403'), findsOneWidget);
    await tester.tap(find.text('Tentar novamente'));
    await tester.runAsync(() async { await Future<void>.delayed(const Duration(milliseconds: 30)); });
    for (var i = 0; i < 20; i++) { await tester.pump(const Duration(milliseconds: 100)); }
    expect(platform.openings, 2);
    expect(find.text('Tentar novamente'), findsNothing);
    expect(tester.takeException(), isNull);
    await tester.pumpWidget(const SizedBox());
    await tester.pump();
  });
}
