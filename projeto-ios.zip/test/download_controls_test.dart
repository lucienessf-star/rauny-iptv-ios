import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:video_player_platform_interface/video_player_platform_interface.dart';
import 'package:rauny_iptv_player/main.dart';
import 'player_layout_test.dart' show LayoutVideoPlatform;

void main() {
  for (final type in ['movie', 'series', 'live']) {
    testWidgets('Download de $type acompanha os controles e usa o vídeo atual', (tester) async {
      SharedPreferences.setMockInitialValues({});
      final old = VideoPlayerPlatform.instance;
      VideoPlayerPlatform.instance = LayoutVideoPlatform();
      addTearDown(() => VideoPlayerPlatform.instance = old);
      tester.view.devicePixelRatio = 1;
      tester.view.physicalSize = const Size(390, 844);
      addTearDown(tester.view.resetPhysicalSize);
      addTearDown(tester.view.resetDevicePixelRatio);
      final calls = <MethodCall>[];
      const channel = MethodChannel('rauny/downloads');
      tester.binding.defaultBinaryMessenger.setMockMethodCallHandler(channel, (call) async {
        calls.add(call);
        return call.method == 'download' ? 42 : null;
      });
      addTearDown(() => tester.binding.defaultBinaryMessenger.setMockMethodCallHandler(channel, null));
      final url = Uri.parse('https://fixture.invalid/$type/episode-7.mp4');
      await tester.pumpWidget(MaterialApp(home: PlayerPage(title: 'Episódio 7',
        url: url, mediaType: type, extension: 'mp4')));
      await tester.pumpAndSettle();
      if (type == 'live') {
        expect(find.text('Baixar filme'), findsNothing);
        expect(find.text('Baixar episódio'), findsNothing);
      } else {
        final label = type == 'series' ? 'Baixar episódio' : 'Baixar filme';
        expect(find.text(label), findsOneWidget);
        tester.view.physicalSize = const Size(844, 390);
        await tester.pumpAndSettle();
        expect(find.text(label), findsOneWidget);
        await tester.pump(const Duration(seconds: 4));
        await tester.pump();
        expect(find.text(label), findsNothing);
        await tester.tapAt(const Offset(420, 100));
        await tester.pump();
        expect(find.text(label), findsOneWidget);
        await tester.tap(find.text(label));
        await tester.pump();
        expect(calls.where((e) => e.method == 'download').length, 1);
        final args = calls.first.arguments as Map;
        expect(args['url'], url.toString());
        expect(args['title'], 'Episódio 7');
        expect(args['mediaType'], type);
        expect(find.text('Download solicitado'), findsOneWidget);
        expect(tester.takeException(), isNull);
      }
      await tester.pumpWidget(const SizedBox());
      await tester.pump();
    });
  }
}
